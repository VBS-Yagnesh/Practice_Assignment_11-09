﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Calculator_Form
{
    public partial class Form1 : Form
    {
        public string num1 = "";
        public string num2 = "";
        public string operate = "";
        public Form1()
        {
            InitializeComponent();
        }


        private void Btn1_Click(object sender, EventArgs e)
        {
            num1 += Btn1.Text;
            ResBox.Text = num1;
        }

        private void Btn2_Click(object sender, EventArgs e)
        {
            num1 += Btn2.Text;
            ResBox.Text = num1;
        }

        private void Btn3_Click(object sender, EventArgs e)
        {
            num1 += Btn3.Text;
            ResBox.Text = num1;
        }

        private void Btn4_Click(object sender, EventArgs e)
        {
            num1 += Btn4.Text;
            ResBox.Text = num1;
        }

        private void Btn5_Click(object sender, EventArgs e)
        {
            num1 += Btn5.Text;
            ResBox.Text = num1;
        }
        private void button6_Click(object sender, EventArgs e)
        {
            num1 += Btn6.Text;
            ResBox.Text = num1;
        }

        private void Btn7_Click(object sender, EventArgs e)
        {
            num1 += Btn7.Text;
            ResBox.Text = num1;
        }

        private void Btn8_Click(object sender, EventArgs e)
        {
            num1 += Btn8.Text;
            ResBox.Text = num1;
        }

        private void Btn9_Click(object sender, EventArgs e)
        {
            num1 += Btn9.Text;
            ResBox.Text = num1;
        }
        private void Btn0_Click(object sender, EventArgs e)
        {
            num1 += Btn0.Text;
            ResBox.Text = num1;
        }

        private void Btndot_Click(object sender, EventArgs e)
        {
            //if (num1.IndexOf(".") == -1)
            //{
                num1 += Btndot.Text;
                ResBox.Text = num1;
        }

        private void Btnadd_Click(object sender, EventArgs e)
        {
            operate = Convert.ToString(Btnadd.Text);
            num2 = num1;
            num1 = "";
            ResBox.Text = operate;
        }
        private void Btnmin_Click(object sender, EventArgs e)
        {
            operate = Btnmin.Text.ToString();
            num2 = num1;
            num1 = "";
            ResBox.Text = operate;
        }

        private void Btnmul_Click(object sender, EventArgs e)
        {
            operate = Btnmul.Text.ToString();
            num2 = num1;
            num1 = "";
            ResBox.Text = operate;
        }

        private void Btndiv_Click(object sender, EventArgs e)
        {
            operate = Btndiv.Text.ToString();
            num2 = num1;
            num1 = "";
            ResBox.Text = operate;
        }

        public string output;
        private void Btnequ_Click(object sender, EventArgs e)
        {
            
            switch (operate)
            {
                case "+" :
                    output = Convert.ToString(Convert.ToDecimal(num1) + Convert.ToDecimal(num2));
                    ResBox.Text = output;
                    break;

                case "-" :
                    output = Convert.ToString(Convert.ToDecimal(num2) - Convert.ToDecimal(num1));
                    ResBox.Text = output;
                    break;
                case "*":
                    output = Convert.ToString(Convert.ToDecimal(num1) * Convert.ToDecimal(num2));
                    ResBox.Text = output;
                    break;
                case "/":
                    if (Convert.ToDecimal(num2) > 0 && Convert.ToDecimal(num1) == 0)
                    {
                        ResBox.Text = "Infinity";
                    }
                    //else if(Convert.ToDecimal(num2) < 0 && Convert.ToDecimal(num1) == 0)
                    //{
                    //    ResBox.Text = "-Infinty";
                    //}
                    else
                    {
                        output = Convert.ToString(Convert.ToDecimal(num2) / Convert.ToDecimal(num1));
                        ResBox.Text = output;
                    }
                    
                    break;
                default:
                    ResBox.Text = "Error";
                    break;
            }
        }

        private void BtnCE_Click(object sender, EventArgs e)
        {
            num1 = num1.Remove(num1.Length - 1, 1);
            ResBox.Text = num1;
        }

        private void BtnC_Click(object sender, EventArgs e)
        {
            ResBox.Text = "";
            num1 = "";
            num2 = "";
            operate = "";
            output = "";
        }

        
    }
}
